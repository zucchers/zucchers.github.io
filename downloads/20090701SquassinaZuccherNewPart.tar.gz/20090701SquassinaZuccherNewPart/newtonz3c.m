function newtonz3c(N,tol,xmin,xmax);
%
% newtonz3c(N,tol,xmin,xmax)
%   Plots the basins of attraction of the complex roots for the equation 
%   z^3-1=0. Blue, red and green discriminate between the three roots, while
%   the darker or lighter colors measure the number of iterations needed to
%   reach the root within a certain tolerance.
%   No output is returned.
%
% Inputs
%   N     Number of pixels in x (and also in y)
%   tol   Tolerance under which the root is considered achieved
%   xmin  Minimum x (and y) in the plot
%   xmax  Maximum x (and y) in the plot
%
%
% Example
%
%   newtonz3c(100,0.1,-2,2);
%
% This version has been tested on:
% + GNU Octave 3.0
% + Matlab 7.4.0.336 (R2007a)
%

% Copyright (C) 2009 Simone Zuccher
%
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
%
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% General Public License for more details.
%
% Author:   Simone Zuccher <zuccher@sci.univr.it>
% Created:  29 May 2009
% Modified: 

% Sanity check
if nargin < 4
   usage ('newtonz3c(N,tol,xmin,xmax)');
   return
end

% Close all previous figures
close all

% One image for each root
ima1=zeros(N,N);
ima2=zeros(N,N);
ima3=zeros(N,N);
% Grid
x=linspace(xmin,xmax,N);
y=linspace(xmin,xmax,N);
% Loop in x and y
for i=1:N
   for j=1:N
      % Initial guess for Newton method
      z0=(x(i)+sqrt(-1)*y(j));
      z=z0;
      % Reset iterazion counter
      count=0;
      % Newton method
      do
         z = (2*z^3+1)/(3*z^2);
         count=count+1;
	 if( abs(z-1)<tol)
	    ima1(i,j)=count;
	    count=0;
	    break;
	 endif
	 if( abs(z-exp(2*pi*sqrt(-1)/3))<tol)
	    ima2(i,j)=count;
	    count=0;
	    break;
	 endif
	 if( abs(z-exp(4*pi*sqrt(-1)/3))<tol)
	    ima3(i,j)=count;
	    count=0;
	    break;
	 endif
      % never-ending loop
      until 0
   end
end

% Some post-processing to make a nice plot...
k=6;
v1=mean(ima1(find(ima1)))*k;
v2=mean(ima2(find(ima2)))*k;
v3=mean(ima3(find(ima3)))*k;
%
f1=sign(sign(sign(v1-ima1)).*(1+sign(sign(v1-ima1)))).*ima1;
f2=sign(sign(sign(v2-ima2)).*(1+sign(sign(v2-ima2)))).*ima2;
f3=sign(sign(sign(v3-ima3)).*(1+sign(sign(v3-ima3)))).*ima3;
%
f1=f1/max(max(f1))/3;
f2=f2/max(max(f2))/3+1/3*sign(f2);
f3=f3/max(max(f3))/3+2/3*sign(f3);
f=f1+f2+f3;
% Rotate and stuff
f=f';
f=flipud(f);

% Make a customized colormap
n=200;
exp=(5);
vmin=1;
vmax=.1;
map=ones(n*3,3)*.9;
map(1:n,1)=(linspace(vmin,vmax,n)).^exp;
map(1:n,2)=(linspace(vmin,vmax,n)).^exp;
map(n+1:2*n,2)=(linspace(vmin,vmax,n)).^exp;
map(n+1:2*n,3)=(linspace(vmin,vmax,n)).^exp;
map(2*n+1:3*n,3)=(linspace(vmin,vmax,n)).^exp;
map(2*n+1:3*n,1)=(linspace(vmin,vmax,n)).^exp;
%test=[linspace(0,1,400);linspace(0,1,400)];
%imagesc(test)
colormap(map)


% Finally, plot the image
imagesc(x,y,f);
axis equal;
axis("tics")

end

function colorjulia(N,nmax,xmin,xmax);
%
% colorjulia(N,nmax,xmin,xmax)
%   Plots the Julia set in color, where the color measures the number of
%   iterations needed to satisfy |z| > M with M = |c| + 1.
%
% Inputs
%   N     Number of pixels in x (and also in y)
%   nmax  Maximum number of iterations
%   xmin  Minimum x (and y) in the plot
%   xmax  Maximum x (and y) in the plot
%
%
% Example
%
%   colorjulia(100,20,-1.5,1.5);
%
% This version has been tested on:
% + GNU Octave 3.0
% + Matlab 7.4.0.336 (R2007a)
%

% Copyright (C) 2009 Simone Zuccher
%
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
%
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% General Public License for more details.
%
% Author:   Simone Zuccher <zuccher@sci.univr.it>
% Created:  29 May 2009
% Modified: 

% Sanity check
if nargin < 4
   usage ('colorjulia(N,nmax,xmin,xmax)');
   return
end

% Close all previous figures
close all


% Constant
c=0.27334-0.00742*sqrt(-1);
% Limit after which convergence is reached
M=abs(c)+1;

ima=zeros(N,N);
x=linspace(xmin,xmax,N);
y=linspace(xmin,xmax,N);

for i=1:N
   for j=1:N
      z0=(x(i)+sqrt(-1)*y(j));
      z=z0;
      count=0;
      do
	 z = z^2+c;
	 count=count+1;
	 if( (abs(z)>M) || (count>=nmax))
	    ima(i,j)=count;
	    if(count>=nmax)
               ima(i,j)=nmax;
	    end
	    count=0;
	    break;
	 endif
      until 0
   end
end

f=ima;
f=f';
f=flipud(f);
f=fliplr(f);
mkmap

imagesc(x,y,f);
colormap(jet)
colorbar

axis equal;
axis("tics")

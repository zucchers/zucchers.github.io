function mandelbrot(alpha,N,Niter,xmin,xmax,ymin,ymax);
%
% mandelbrot(alpha,N,Niter,xmin,xmax,ymin,ymax)
%   Plots the generalized Mandelbrot set from the complex map f(z) = z^2 + c.
%
% Inputs
%   alpha Exponent, alpha>1.  alpha>2 => generalized Mandelbrot
%   N     Number of pixels in x (and also in y)
%   Niter Maximum number of iterations
%   xmin  Minimum x in the plot
%   xmax  Maximum x in the plot
%   ymin  Minimum y in the plot
%   ymax  Maximum y in the plot
%
%
% Example
%
%   mandelbrot(2,500,50,-1.9,.6,-1.25,1.25);
%
% This version has been tested on:
% + GNU Octave 3.0
% + Matlab 7.4.0.336 (R2007a)
%

% Copyright (C) 2009 Simone Zuccher
%
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
%
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% General Public License for more details.
%
% Author:   Simone Zuccher <zuccher@sci.univr.it>
% Created:  04 Jul 2009
% Modified: 

% Sanity check
if nargin < 7
   usage ('mandelbrot(alpha,N,Niter,xmin,xmax,ymin,ymax)');
   return
end

% Close all previous figures
close all

% Grid
x = linspace(xmin,xmax,N);
y = linspace(ymin,ymax,N)';

% Matrix c of initial conditions
[Re,Im] = meshgrid(x,y);
c = Re + sqrt(-1)*Im;

% Matrix z
z = zeros(size(c));
zplot=z;

% Loop
for l = 1:Niter
    z = z.^alpha + c;
    %  if |z| > 2 the sequence diverges
    zplot = zplot + (abs(z)<2);
end;

% Plot
imagesc(zplot);
colormap(flipud(gray(64)))
axis equal
axis square
axis off

function julia(c,N,Niter,xmin,xmax,ymin,ymax);
%
% julia(c,N,Niter,xmin,xmax,ymin,ymax)
%   Plots the Julia set from the complex map f(z) = z^2 + c.
%
% Inputs
%   c     Complex constant of the Julia set
%   N     Number of pixels in x (and also in y)
%   Niter Maximum number of iterations
%   xmin  Minimum x in the plot
%   xmax  Maximum x in the plot
%   ymin  Minimum y in the plot
%   ymax  Maximum y in the plot
%
%
% Example
%
%   julia(-.08+.75*i,500,50,-1.3,1.3,-1.3,1.3);
%
% This version has been tested on:
% + GNU Octave 3.0
% + Matlab 7.4.0.336 (R2007a)
%

% Copyright (C) 2009 Simone Zuccher
%
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
%
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% General Public License for more details.
%
% Author:   Simone Zuccher <zuccher@sci.univr.it>
% Created:  04 Jul 2009
% Modified: 

% Sanity check
if nargin < 7
   usage ('julia(c,N,Niter,xmin,xmax,ymin,ymax)');
   return
end

% Close all previous figures
close all

% Grid
x = linspace(xmin,xmax,N);
y = linspace(ymin,ymax,N)';
% This is needed to avoid `numerical explosions'
R = max(abs([xmin xmax ymin ymax]));

% Matrix of initial conditions
[Re,Im] = meshgrid(x,y);
z = Re + sqrt(-1)*Im;
z=flipud(z);
zplot = zeros(size(z));

% Loop
for i = 1:Niter
    %  if |z| > R the sequence diverges
    zplot = zplot+(abs(z)<=R);
    z = z.*z+ones(size(z))*c;
end

% Plot
imagesc(zplot);
colormap(flipud(gray(64)))
axis equal
axis square
axis off
